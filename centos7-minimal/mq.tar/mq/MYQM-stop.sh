#!/bin/bash
docker stop MYQM