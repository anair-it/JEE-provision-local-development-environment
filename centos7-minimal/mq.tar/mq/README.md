# _MYQM_ Websphere Queue manager docker build
- Build a docker image that has _MYQM_ Queue manager for local development purpose only.
- Replace _MYQM_ with the correct Queue manager name and replace _company_ with the docker company domain name
- Replace *.sh script names to match the Queue manager name

>Docker hub: https://hub.docker.com/r/anoopnair/ibm-mq-debian/

## Building image
- ``docker build -t mycompany/ibm-mq-myqm:7.5.0 .``

## Creating container
Run this cmd only if a container is not created. Possibly a one-time step.
``docker run --privileged --name MYQM -e LICENSE=accept -e MQ_QMGR_NAME=MYQM -v /var/mqm:/var/mqm -p 1414:1414 -d mycompany/ibm-mq-myqm:7.5.0``

## Start Queue manager
- ``./MYQM-start.sh``
- OR run the cmd ``docker start MYQM``

## Stop queue manager
- ``./MYQM-stop.sh``
- OR run the cmd ``docker stop MYQM``

## MQSC
### Adding a new MQ config like queue/topic
- Add queue configs in config.mqsc file
- Stop running container
- Build image again
- Start container