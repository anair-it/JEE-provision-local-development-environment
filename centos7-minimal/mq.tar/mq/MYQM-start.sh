#!/bin/bash
docker stop MYQM
docker start MYQM