#!/bin/bash
docker stop local-oracle