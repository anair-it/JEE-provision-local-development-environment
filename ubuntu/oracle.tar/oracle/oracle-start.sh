#!/bin/bash
docker stop local-oracle
docker start local-oracle