Version: 3.1.8.RELEASE
Build Date: 20170106192608

* Adds a Non-Blocking IO (NIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration