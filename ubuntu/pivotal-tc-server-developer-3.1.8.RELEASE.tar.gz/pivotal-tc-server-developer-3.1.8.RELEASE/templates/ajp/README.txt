Version: 3.1.8.RELEASE
Build Date: 20170106192608

* Adds an Apache JServ Protocol (AJP) connector