Version: 3.1.8.RELEASE
Build Date: 20170106192608

* Updates the JmxSocketListener to use SSL for all JMX communication
* Adds sample certificate and key files that can be used to test the SSL configuration