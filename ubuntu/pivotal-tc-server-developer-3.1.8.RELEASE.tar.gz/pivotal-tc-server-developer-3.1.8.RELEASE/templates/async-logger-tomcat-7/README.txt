Version: 3.1.8.RELEASE
Build Date: 20170106192608

* Adds asynchronous logging