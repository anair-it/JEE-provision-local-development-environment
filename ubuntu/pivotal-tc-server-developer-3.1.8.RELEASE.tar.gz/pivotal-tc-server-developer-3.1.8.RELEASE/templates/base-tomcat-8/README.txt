Version: 3.1.8.RELEASE
Build Date: 20170106192608

* Add Tomcat 8-specific Servlet 3.1 Specification
* Add Tomcat 8-specific web.xml as a watched resource
