Version: 1.0.0.RELEASE
Build Date: 20140729205343

* Adds and configures Redis Session Manager on the instance
	* Adds the required redis session manager libraries to lib directory
	* Adds an entry into context.xml for the valve and manager configuration
	* Requires a password be set for the redis configuration
