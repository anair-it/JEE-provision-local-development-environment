Version: 3.1.8.RELEASE
Build Date: 20170106192608

* Adds an APRLifecycleListener to detect the APR-based native library required to use the APR/native connector
* Adds an APR/native (APR) connector for HTTP

NOTE: That the APR/native library must be present in order to use the APR connector